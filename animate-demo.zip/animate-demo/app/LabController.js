angular.module('app')
    .controller('LabController', [
        function () {
            var vm = this;
        }
    ]);